

function Calc_Charge()
{
    var no_of_units=parseInt(document.getElementById("NOU").value);
	var number=parseInt(document.getElementById("C_No").value);
	var name=document.getElementById("C_Name").value;
	var mail=document.getElementById("C_Email").value;
	var charge=0;
	
	
	if(no_of_units<=100)
	{
		charge=( no_of_units * 2.96 );
	}
	else
	{
		charge=(no_of_units * 5.56);
	}
	
	
	alert("Consumer Number : "+number+"; Consumer Name : "+name+"; Units Consumed : "+no_of_units+";email: "+mail+" Charge : "+charge);
	return false;
}

