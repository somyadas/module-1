*********************Question 2***********************
Q2.
   1.  select cOnsumerno ,cOnsumername from electricity_consumer 
       where unitsconsumed 
	   in(select max(unitsconsumed) FROM electricity_consumer );
	   
	   
	   CONSUMERNO             CONSUMERNAME         
---------------------- -------------------- 
12432121               Manoj Kulkarni       

1 rows selected


   3. SELECT C.consumername FROM  electricity_consumer C WHERE  C.consumerno IN
      (SELECT B.CONSUMERNO FROM electricity_bill B WHERE  TO_CHAR(billpaiddate,'DD')>=15  AND  b.consumerno= c.consumerno) ;
	  
	  CONSUMERNAME         
-------------------- 
Mahesh B             
Manoj Kulkarni       
Shrikant Shinde      
Seema Joshi          
Amey Joshi           
Pravin T             

6 rows selected

