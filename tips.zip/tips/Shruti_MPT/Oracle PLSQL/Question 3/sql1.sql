******************************Question 3*******************************

3.  ALTER TABLE electricity_consumer ADD billPaymentDate DATE;

                       ALTER TABLE electricity_consumer succeeded.
					   
					   
					   
    ALTER TABLE electricity_consumer ADD billPaymentdueDate  DATE;
	            
				        ALTER TABLE electricity_consumer succeeded.

						
	ALTER TABLE electricity_consumer ADD CHECK((billPaymentdueDate-billPaymentDate)<7);
	     
		                ALTER TABLE electricity_consumer succeeded.
