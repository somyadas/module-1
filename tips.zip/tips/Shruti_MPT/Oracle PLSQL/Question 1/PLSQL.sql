************************PLSQL************************************
File Name:          Total_Electricity_Charge.txt
Author Name:        Shruti Sharma
Description:        Calculate the electricity Charges
Version:            1.0
Last Modified Date: 28-OCT-2016

****************************************************************
CREATE OR REPLACE PROCEDURE electricity_bill_calculation(v_consumer_no  NUMBER)
IS
v_bill_amount electricity_bill.billamount%TYPE;
elec_rec electricity_consumer%ROWTYPE;
CURSOR c1 IS SELECT * FROM electricity_consumer WHERE consumerno=v_consumer_no;
e1 EXCEPTION;
BEGIN
   
     FOR elec_rec IN c1
     LOOP
      IF (elec_rec.unitsconsumed<100) THEN
        v_bill_amount:=(2.96*elec_rec.unitsconsumed);
      ELSIF (elec_rec.unitsconsumed>100) THEN
        v_bill_amount:=((100*2.96)+((elec_rec.unitsconsumed-100)*5.56));
      ELSE
        RAISE e1;
      END IF;
      INSERT INTO electricity_bill VALUES (BillID_Seq.nextVal,v_consumer_no,v_bill_amount,sysdate);
    END LOOP;
    
EXCEPTION 
  WHEN e1 THEN
    dbms_output.put_line('--------invalid units---------');    
  WHEN no_data_found THEN
    dbms_output.put_line('--------invalid consumer code----------');
END;


DECLARE
v_consumer_no1 NUMBER;
BEGIN
electricity_bill_calculation(&v_consumer_no1);
END;


***************************OUTPUT**************************************************
                     PROCEDURE electricity_bill_calculation(v_consumer_no Compiled.
					 anonymous block completed

					 
					 
