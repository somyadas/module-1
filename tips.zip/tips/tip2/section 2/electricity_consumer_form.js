function calculate()
{
var electricity_charge;
if(document.form4.no_of_units.value<=100)
{
	electricity_charge=document.form4.no_of_units.value*2.96;
	alert("consumer no:"+document.form4.cno.value+"\nconsumer name:"+document.form4.cname.value+"\nemail:"
	      +document.form4.email.value+"\nno of calls:"+document.form4.no_of_units.value+"\ntotal electricity_charge:"+electricity_charge);
}
else
{
    cost=document.form4.calls.value*5.56;
	alert("consumer no:"+document.form4.cno.value+"\nconsumer name:"+document.form4.cname.value+"\nemail:"
	      +document.form4.email.value+"\nno of calls:"+document.form4.no_of_units.value+"\ntotal electricity_charge:"+electricity_charge);

	}
}