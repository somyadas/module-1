function validate(){
var name=document.frmReg.nameF.value;
alert("All data for"+name+"entered successfully");
}