<script>
	function validateForm(){
	var x=document.forms["myForm"]["fname"].value;
	if(x == " ")
	alert="Enter your first name";
	return false;
	}
</script>