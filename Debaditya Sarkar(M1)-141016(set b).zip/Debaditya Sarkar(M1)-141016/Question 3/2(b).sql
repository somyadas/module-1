
SQL> select product_name
  2  from orders
  3  where quantity=3;