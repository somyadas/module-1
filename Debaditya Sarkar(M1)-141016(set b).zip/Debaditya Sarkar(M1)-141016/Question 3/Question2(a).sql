
SQL> select * from orders
  2  join customer
  3  on(orders.customer_id=customer.customer_id)
  4  where(customer.customer_name='ROBERT');