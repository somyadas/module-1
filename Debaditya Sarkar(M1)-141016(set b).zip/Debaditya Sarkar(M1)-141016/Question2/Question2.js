function validate()
{
	  var name=document.getElementById('name').value;
	  if (name=="")
	  {
		  alert("Please Enter your name");
		  return false;
	  }
	  else if(name.length<3)
	  {
		alert("Name Too short."); 
		return false;		
	  }
	  else 
	  {
		  for(i=0;i<name.length;i++)
		  {
		    var ch=name.charAt(i);
		    //alert(ch);
		    if( (ch <= 'Z' && ch >='A') || (ch <= 'z' && ch >='a'))
		    	{
				
					//document.getElementById("n1").innerHTML="Invalid Character";
		    	}
		  
		    else
		    	{
					alert("only characters are allowed.");
					return false;
		    	}
		  }
	  }
	  
	  
	  var tel=document.getElementById('phone').value;
	  
	  if(tel == "")
	  {
		  alert("Please Enter tel");
		  return false;
	  }
	 else if(isNaN(tel)){
		 alert("invalid no.");
	 }
	 else if(tel.length <1 || tel.length>11)
	  {
		alert("Invalid Num");  
	  }
	  else if(tel.length != 10)
	  {
		alert("Invalid Num1");  
	  }
	  
	  var email=document.getElementById('email').value;
	  if(email=="")
	  {
		  alert("enter the email");
		  return false;
	  }
	  else
	  {
		var quantity = document.getElementById('quantity').value;
		var price = document.getElementById('price').value;
		var calc=0;
		calc = price*quantity;
	   alert("Total Amount="+calc);
		}

	 
	}
 