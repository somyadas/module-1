package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.bean.PurchaseDetailsBean;
import com.cg.exception.MiniProjectException;
import com.cg.util.DBConnection;

public class TrainingCoordinatorsDAOImpl implements ITrainingCoordinatorsDAO 
{
	@Override
	public boolean insertPurchase(PurchaseDetailsBean purchaseDetailsBean)throws MiniProjectException 
	{
		int records = 0;
		boolean isInserted = false;

		try (Connection connPurchaseDetails = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connPurchaseDetails
						.prepareStatement(QueryMapperTrainingCoordinators.INSERT_PURCHASE);) 
						
						{
							java.sql.Date purchaseDate = new Date(new java.util.Date().getTime());
			
							preparedStatement.setInt(1,purchaseDetailsBean.getPurchaseId());
							preparedStatement.setString(2,purchaseDetailsBean.getName());
							preparedStatement.setString(3,purchaseDetailsBean.getMailId());
							preparedStatement.setString(4,purchaseDetailsBean.getphoneNo());
							preparedStatement.setDate(5,purchaseDate);
							preparedStatement.setInt(6,purchaseDetailsBean.getMobileId());

							records = preparedStatement.executeUpdate();

							if (records > 0) 
							{
								isInserted = true;
							}

						} 
		catch (SQLException sqlEx) 
		{
			throw new MiniProjectException(sqlEx.getMessage());
		}
		
		return isInserted;
	}

	@Override
	public boolean deletePurchaseDetails(int mobileId)throws MiniProjectException
	{
		int records = 0;
		boolean isDeleted = false;

		try (Connection connPurchaseDetails = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connPurchaseDetails
						.prepareStatement(QueryMapperTrainingCoordinators.DELETE_PURCHASE);) 
						
						{
			
							preparedStatement.setInt(1,mobileId);

							records = preparedStatement.executeUpdate();

							if (records > 0) 
							{
								isDeleted = true;
							}

						} 
		catch (SQLException sqlEx) 
		{
			throw new MiniProjectException(sqlEx.getMessage());
		}
		
		return isDeleted;
	}

}
