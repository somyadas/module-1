package com.cg.dao;

import com.cg.exception.MiniProjectException;

public interface ITrainingCoordinatorsDAO 
{
	public boolean insertPurchase
	(final PurchaseDetailsBean purchaseDetailsBean) 
			throws MiniProjectException;
	
	public boolean deletePurchaseDetails(final int mobileId)
	throws MiniProjectException;

}
