package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.MiniProjectException;
import com.cg.util.DBConnection;

public class TrainingAdminDAOImpl implements ITrainingAdminDAO 
{

	@Override
	public List<FacultySkillBean> facultyList() throws MiniProjectException {
		
		List<FacultySkillBean>facultyList = new ArrayList<FacultySkillBean>();

		try (Connection connMobile = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connMobile.prepareStatement(QueryMapperTrainingAdmin.VIEW_FACULTYLIST);
				ResultSet rsFaculties = preparedStatement.executeQuery();
				) 
				{
					while(rsFaculties.next())
					{
						FacultySkillBean faculty = new FacultySkillBean();
						faculty.setEmployeeId(rsFaculties.getString("employeeId"));
						faculty.setSkillSet(rsFaculties.getString("skillSet"));
						facultyList.add(faculty);
					}
		
					if(facultyList.size() == 0){
						throw new MiniProjectException("No records found.");
					} 
				
				} catch (SQLException sqlEx) {
					throw new MiniProjectException(sqlEx.getMessage());
				}
		
		return facultyList;
	}

	@Override
	public List<CourseMasterBean> courseList() throws MiniProjectException {
		
		List<CourseMasterBean>courseList = new ArrayList<CourseMasterBean>();

		try (Connection connMobile = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connMobile.prepareStatement(QueryMapperTrainingAdmin.VIEW_FACULTYLIST);
				ResultSet rsCourses = preparedStatement.executeQuery();
				) 
				{
					while(rsCourses.next())
					{
						CourseMasterBean course = new CourseMasterBean();
						course.setCourseCode(rsCourses.getString("courseCode"));
						courseList.add(course);
					}
		
					if(courseList.size() == 0){
						throw new MiniProjectException("No records found.");
					} 
				
				} catch (SQLException sqlEx) {
					throw new MiniProjectException(sqlEx.getMessage());
				}
		
		return courseList;
	}

	@Override
	public List<CourseMasterBean> courseMaintenance() throws MiniProjectException {
		
		List<CourseMasterBean>courseList = new ArrayList<CourseMasterBean>();

		try (Connection connMobile = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connMobile.prepareStatement(QueryMapperTrainingAdmin.VIEW_FACULTYLIST);
				ResultSet rsCourses = preparedStatement.executeQuery();
				) 
				{
					while(rsCourses.next())
					{
						CourseMasterBean course = new CourseMasterBean();
						course.setCourseName(rsCourses.getString("courseName"));
						course.setNoOfDays(rsCourses.getInt("noOfDays"));
						courseList.add(course);
					}
		
					if(courseList.size() == 0){
						throw new MiniProjectException("No records found.");
					} 
				
				} catch (SQLException sqlEx) {
					throw new MiniProjectException(sqlEx.getMessage());
				}
		
		return courseList;
	}

	@Override
	public List<FeedbackMasterBean> viewFeedbackReportTraining(String trainingCode) throws MiniProjectException {
		
		List<FeedbackMasterBean>vfrtList = new ArrayList<FeedbackMasterBean>();

		try (Connection connMobile = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connMobile.prepareStatement(QueryMapperTrainingAdmin.VIEW_FACULTYLIST);
				ResultSet rsvfrt = preparedStatement.executeQuery();
				) 
				{
					while(rsvfrt.next())
					{
						FeedbackMasterBean vfrt = new FeedbackMasterBean();
						vfrt.setTrainingCode(rsvfrt.getString("trainingCode"));
						vfrt.setPresentationCommunication(rsvfrt.getString("presentationCommunication"));
						vfrt.setClearifyDoubts(rsvfrt.getString("clearifyDoubts"));
						vfrt.setTimeManagement(rsvfrt.getString("timeManagement"));
						vfrt.setHandOuts(rsvfrt.getString("handOuts"));
						vfrt.setHwSwNw(rsvfrt.getString("hwSwNw"));
						vfrt.setComments(rsvfrt.getString("comments"));
						vfrt.setSuggestions(rsvfrt.getString("suggestions"));
						
						vfrtList.add(vfrt);
					}
		
					if(vfrtList.size() == 0){
						throw new MiniProjectException("No records found.");
					} 
				
				} catch (SQLException sqlEx) {
					throw new MiniProjectException(sqlEx.getMessage());
				}
		
		return vfrtList;

	}

	@Override
	public List<FeedbackMasterBean> viewFeedbackReportFaculty(String employeeId) throws MiniProjectException {
		
		List<FeedbackMasterBean>vfrfList = new ArrayList<FeedbackMasterBean>();

		try (Connection connMobile = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connMobile.prepareStatement(QueryMapperTrainingAdmin.VIEW_FACULTYLIST);
				ResultSet rsvfrf = preparedStatement.executeQuery();
				) 
				{
					while(rsvfrf.next())
					{
						FeedbackMasterBean vfrf = new FeedbackMasterBean();
						vfrf.setEmployeeId(rsvfrf.getString("employeeId"));
						vfrf.setPresentationCommunication(rsvfrf.getString("presentationCommunication"));
						vfrf.setClearifyDoubts(rsvfrf.getString("clearifyDoubts"));
						vfrf.setTimeManagement(rsvfrf.getString("timeManagement"));
						vfrf.setHandOuts(rsvfrf.getString("handOuts"));
						vfrf.setHwSwNw(rsvfrf.getString("hwSwNw"));
						vfrf.setComments(rsvfrf.getString("comments"));
						vfrf.setSuggestions(rsvfrf.getString("suggestions"));
						
						vfrfList.add(vfrf);
					}
		
					if(vfrfList.size() == 0){
						throw new MiniProjectException("No records found.");
					} 
				
				} catch (SQLException sqlEx) {
					throw new MiniProjectException(sqlEx.getMessage());
				}
		
		return vfrfList;
		
	}
}

