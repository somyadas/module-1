package com.cg.dao;


public interface QueryMapperParticipants {

		public static final String INSERT_PARTICIPANT_FEEDBACK = 
			"INSERT INTO feedbackmaster VALUES(?,?,?,?,?,?,?,?,?)";
}
