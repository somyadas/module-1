package com.cg.dao;

public interface QueryMapperTrainingAdmin {
	
	public static final String VIEW_COURSELIST = 
			"SELECT * FROM CourseMaster";
	
	public static final String VIEW_FACULTYLIST =
			"SELECT * FROM FacultySkill";
	
	public static final String VIEW_VIEWFEEDBACKREPORTTRAINING =
			"SELECT  presentationCommunication, clearifyDoubts, timeManagement, handOuts, hwSwNw"
			+ "FROM FeedbackMaster WHERE trainingCode=? ";
	
	public static final String VIEW_VIEWFEEDBACKREPORTFACULTY =
			"SELECT  presentationCommunication, clearifyDoubts, timeManagement, handOuts, hwSwNw"
			+ "FROM FeedbackMaster WHERE employeeId=? ";
	
	public static final String VIEW_COURSEMAINTENANCE =
			"SELECT coursename, noofdays"
			+ "FROM CourseMaster ";

}
