package com.cg.dao;

import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.MiniProjectException;

public interface IParticipantsDAO {
	
	public int addFeedback(FeedbackMasterBean feedbackMaster ) throws MiniProjectException;

}
