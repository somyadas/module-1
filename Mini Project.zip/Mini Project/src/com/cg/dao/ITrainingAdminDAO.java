package com.cg.dao;

import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.MiniProjectException;

public interface ITrainingAdminDAO 
{
	
	public List<FacultySkillBean> facultyList() throws MiniProjectException;
	
	public List<CourseMasterBean> courseList() throws MiniProjectException;
	
	public List<CourseMasterBean> courseMaintenance() throws MiniProjectException;
	
	public List<FeedbackMasterBean> viewFeedbackReportTraining(String trainingCode) throws MiniProjectException;
	
	public List<FeedbackMasterBean> viewFeedbackReportFaculty(String employeeId) throws MiniProjectException;


}
