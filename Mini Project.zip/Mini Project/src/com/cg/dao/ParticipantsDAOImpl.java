package com.cg.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.MiniProjectException;
import com.cg.util.DBConnection;


public class ParticipantsDAOImpl implements IParticipantsDAO {

	@Override
	public int addFeedback(FeedbackMasterBean feedbackMaster)
			throws MiniProjectException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		int record=0;
		
		try {
			
			preparedStatement=connection.prepareStatement(QueryMapperParticipants.INSERT_PARTICIPANT_FEEDBACK);
			preparedStatement.setInt(1, feedbackMaster.getTrainingCode());
			preparedStatement.setInt(2, feedbackMaster.getEmployeeId());
			preparedStatement.setInt(3, feedbackMaster.getPresentationCommunication());
			preparedStatement.setInt(4, feedbackMaster.getClearifyDoubts());
			preparedStatement.setInt(5, feedbackMaster.getTimeManagement());
			preparedStatement.setInt(6, feedbackMaster.getHandOuts());
			preparedStatement.setInt(7, feedbackMaster.getHwSwNtwrk());
			preparedStatement.setString(8, feedbackMaster.getComments());
			preparedStatement.setString(9, feedbackMaster.getSuggestions());
			
			record=preparedStatement.executeUpdate();
		
		if(record==0)
		{
		throw new MiniProjectException("Record not inserted");
		}
		else
		{
			
			return record;
		}
		
	} 
		catch(SQLException s)
		{
			s.printStackTrace();
			}
		catch (MiniProjectException e) {
		e.getMessage();
	}
		return record;
	}
}



