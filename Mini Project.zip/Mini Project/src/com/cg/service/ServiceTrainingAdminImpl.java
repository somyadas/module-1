package com.cg.service;

import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.dao.ITrainingAdminDAO;
import com.cg.dao.ITrainingCoordinatorsDAO;
import com.cg.dao.TrainingAdminDAOImpl;
import com.cg.dao.TrainingCoordinatorsDAOImpl;
import com.cg.exception.MiniProjectException;

public class ServiceTrainingAdminImpl implements IServiceTrainingAdmin {
	
	private ITrainingAdminDAO trainingadminDAO;
	
	public ServiceTrainingAdminImpl() {
		
		trainingadminDAO = new TrainingAdminDAOImpl();
	}

	@Override
	public List<FacultySkillBean> facultyList() throws MiniProjectException {
		
		List<FacultySkillBean> facultyList = trainingadminDAO.facultyList(); 
		return facultyList;
	}

	@Override
	public List<CourseMasterBean> courseList() throws MiniProjectException {
		
		List<CourseMasterBean> courseList = trainingadminDAO.courseList(); 
		return courseList;
	}

	@Override
	public List<CourseMasterBean> courseMaintenance() throws MiniProjectException {
		
		List<CourseMasterBean> courseList = trainingadminDAO.courseMaintenance(); 
		return courseList;
	}

	@Override
	public List<FeedbackMasterBean> viewFeedbackReportTraining(String trainingCode) throws MiniProjectException {
		List<FeedbackMasterBean> vfrt = trainingadminDAO.viewFeedbackReportTraining(trainingCode); 
		return vfrt;
	}

	@Override
	public List<FeedbackMasterBean> viewFeedbackReportFaculty(String employeeId) throws MiniProjectException {
		
		List<FeedbackMasterBean> vfrf = trainingadminDAO.viewFeedbackReportTraining(employeeId); 
		return vfrf;
	}

}
