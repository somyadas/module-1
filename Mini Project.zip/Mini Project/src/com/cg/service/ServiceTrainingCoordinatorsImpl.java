package com.cg.service;

import com.cg.bean.PurchaseDetailsBean;
import com.cg.dao.ITrainingCoordinatorsDAO;
import com.cg.dao.TrainingCoordinatorsDAOImpl;
import com.cg.exception.MiniProjectException;

public class ServiceTrainingCoordinatorsImpl implements IServiceTrainingCoordinators {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MiniProjectException {
		
		ITrainingCoordinatorsDAO purchaseDetailsDAO = new TrainingCoordinatorsDAOImpl();
		
		boolean isItInserted = purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
		
		return isItInserted;
	}


}
