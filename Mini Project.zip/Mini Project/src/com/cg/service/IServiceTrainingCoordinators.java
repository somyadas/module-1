package com.cg.service;

import com.cg.exception.MiniProjectException;

public interface IServiceTrainingCoordinators {
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MiniProjectException;


}
