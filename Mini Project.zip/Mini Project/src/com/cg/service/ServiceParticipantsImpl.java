package com.cg.service;

public class ServiceParticipantsImpl implements IServiceParticipants {

}
