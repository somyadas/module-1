package com.cg.exception;

public class MiniProjectException extends Exception 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4473513424240627536L;
	
	public MiniProjectException()
	{
		//For good programming practice add super 
		super();
	}

	public MiniProjectException(String message) 
	{
		super(message);
		
	}

}
