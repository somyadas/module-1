package com.cg.pi;

import java.time.LocalDate;

import com.cg.exception.MiniProjectException;
import com.cg.service.IServiceTrainingAdmin;
import com.cg.service.ServiceTrainingAdminImpl;

public class MiniProjectMain {

	public static void main(String[] args) {
	    
		IServiceTrainingAdmin ista = new ServiceTrainingAdminImpl();
		
		try {
			boolean isInserted = isp.insertPurchaseDetails(pdb);
			
			if(isInserted){
				System.out.println("Record inserted successfully");
			}
			
		} catch (MiniProjectException mpe) {
			System.out.println(mpe.getMessage());
			// TODO: handle exception
		}

	}

}
