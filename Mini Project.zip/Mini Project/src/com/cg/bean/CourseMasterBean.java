package com.cg.bean;

public class CourseMasterBean {
	
	private String courseCode;
	private String courseName;
	private int noOfDays;
	
	public CourseMasterBean() {
		super();
	}

	public CourseMasterBean(String courseCode, String courseName, int noOfDays) {
		super();
		this.courseCode = courseCode;
		this.courseName = courseName;
		this.noOfDays = noOfDays;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	@Override
	public String toString() {
		return "CourseMasterBean [courseCode=" + courseCode + ", courseName=" + courseName + ", noOfDays=" + noOfDays
				+ "]";
	}
	
	
}
