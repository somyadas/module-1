package com.cg.bean;

public class FacultySkillBean {
	
	private String employeeId;
	private String skillSet;
	
	public FacultySkillBean() {
		super();
	}

	public FacultySkillBean(String employeeId, String skillSet) {
		super();
		this.employeeId = employeeId;
		this.skillSet = skillSet;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	@Override
	public String toString() {
		return "FacultySkill [employeeId=" + employeeId + ", skillSet=" + skillSet + "]";
	}
	
}

