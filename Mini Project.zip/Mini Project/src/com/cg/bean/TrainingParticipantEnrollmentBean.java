package com.cg.bean;

public class TrainingParticipantEnrollmentBean {
	
	private String trainingCode;
	private String employeeId;
	
	public TrainingParticipantEnrollmentBean() {
		super();
	}

	public TrainingParticipantEnrollmentBean(String trainingCode, String employeeId) {
		super();
		this.trainingCode = trainingCode;
		this.employeeId = employeeId;
	}

	public String getTrainingCode() {
		return trainingCode;
	}

	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	@Override
	public String toString() {
		return "TrainingParticipantEnrollment [trainingCode=" + trainingCode + ", employeeId=" + employeeId + "]";
	}
	
	
}
